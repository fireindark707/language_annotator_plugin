# Language Annotator

Language Annotator is a browser extension for vocabulary learning in real web context.

It highlights your saved words, lets you add new words quickly, provides instant translation, and automatically accumulates example sentences while you browse.

Chrome Web Store:  
https://chromewebstore.google.com/detail/language-annotator/pplocadbndpadfenglgleehcfjaciobg

## Core Features

- Word highlighting on pages for saved vocabulary.
- Right-click add word flow with prefilled translation.
- Popup + full-page word manager (`popup.html`, `words.html`).
- Mark as learned / unmark / pronounce / delete actions.
- Automatic translation overlay for selected text (configurable).
- UI language switch (multi-language).
- Cross-device sync via storage sync sharding.
- Import / export vocabulary data.
- Domain exclusion list in Settings (editable by user).

## Automatic Example Collection (Latest)

- Auto-collects example sentences for saved words from newly visited pages.
- Sentence quality filtering:
  - removes low-information samples (e.g. only the word itself),
  - removes link-heavy/URL-like strings,
  - rejects over-similar or containment-duplicate samples.
- Supports pinned examples:
  - pinned examples stay on top,
  - pinned examples are not counted in the unpinned limit.
- Current limit:
  - max 20 unpinned examples per word.
- Example metadata:
  - source URL and capture timestamp.
- Example operations:
  - per-example pin/unpin and delete.
- Example translation behavior:
  - queue + concurrency limit,
  - visible-item translation (IntersectionObserver),
  - translation cache and persistence.

## Hover Learning Card

When hovering a highlighted word on page:

- shows meaning,
- shows up to 3 example sentences,
- includes sentence-level highlight of the target word,
- shows per-sentence translation.

## Settings

`options.html` provides:

- translation source language,
- UI language,
- auto-translate on selection toggle,
- editable excluded domains list,
- import/export data.

## Storage Model

- `chrome.storage.local`: active runtime data.
- `chrome.storage.sync`: synced backup (sharded, size-safe).
- Main data key: `words` (logical), with sync shards under `words_shard_v2_*`.

## Browser Targets

This repo supports both Chrome and Firefox with target-specific manifest templates:

- `manifests/manifest.chrome.json`
- `manifests/manifest.firefox.json`

Build script:

```bash
./scripts/build-extension.sh chrome
./scripts/build-extension.sh firefox
```

Output packages:

- `dist/language-annotator-chrome-v<version>.zip`
- `dist/language-annotator-firefox-v<version>.zip`

## Local Development

1. Load extension unpacked:
   - Chrome: `chrome://extensions` -> Developer mode -> Load unpacked
   - Firefox: `about:debugging` -> This Firefox -> Load Temporary Add-on
2. Test main flows:
   - highlight and context menu add,
   - popup/words actions,
   - automatic example collection,
   - excluded domain behavior,
   - import/export.

## Version

Current manifest version: `1.2`.
