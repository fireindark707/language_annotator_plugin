// background.js
if (typeof importScripts === "function") {
	importScripts("storage.js");
}

chrome.runtime.onInstalled.addListener(function () {
	chrome.contextMenus.create({
		id: "addWord",
		title: "Add Word to Annotator Vocabulary",
		contexts: ["selection"],
	});

	WordStorage.init();
});

chrome.runtime.onStartup.addListener(function () {
	WordStorage.init();
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
	if (info.menuItemId === "addWord" && info.selectionText) {
		const word = info.selectionText.trim();
		if (!tab || !tab.id) return;
		chrome.tabs.sendMessage(tab.id, { action: "openAddWordModal", word: word }, function () {
			if (chrome.runtime.lastError) {
				console.error("Failed to open add-word modal:", chrome.runtime.lastError);
			}
		});
	}
});

function translateWithGoogle(text, sourceLang, targetLang) {
	const sl = sourceLang || "auto";
	const tl = targetLang || navigator.language || "en";
	const apiUrl = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&hl=en-US&dt=t&dt=bd&dj=1&source=input&q=${encodeURIComponent(text)}`;
	return fetch(apiUrl)
		.then((response) => response.json())
		.then((data) => {
			if (data && data.sentences && data.sentences.length > 0) {
				return data.sentences.map((s) => s.trans).join(" ");
			}
			return "";
		});
}

function flattenDictionaryEntries(node, out, inheritedPos) {
	if (!node) return;
	if (Array.isArray(node)) {
		node.forEach((item) => flattenDictionaryEntries(item, out, inheritedPos));
		return;
	}
	if (typeof node !== "object") return;

	const pos = node.kelas || node.class || node.pos || node.jenis_kata || inheritedPos || "";
	const definition =
		node.arti || node.definisi || node.definition || node.deskripsi || node.desc || "";

	if (typeof definition === "string" && definition.trim()) {
		out.push({
			pos: typeof pos === "string" ? pos.trim() : "",
			definition: definition.trim(),
		});
	}

	Object.keys(node).forEach((key) => {
		flattenDictionaryEntries(node[key], out, pos);
	});
}

function lookupKateglo(word) {
	const url = `https://kateglo.lostfocus.org/api.php?format=json&phrase=${encodeURIComponent(word)}`;
	return fetch(url)
		.then((response) => response.json())
		.then((data) => {
			const entries = [];
			flattenDictionaryEntries(data, entries, "");
			const dedup = [];
			const seen = new Set();
			entries.forEach((item) => {
				const key = `${(item.pos || "").toLowerCase()}__${(item.definition || "").toLowerCase()}`;
				if (!item.definition || seen.has(key)) return;
				seen.add(key);
				dedup.push(item);
			});
			return {
				found: dedup.length > 0,
				source: "kateglo",
				entries: dedup.slice(0, 5),
			};
		});
}

// 用于翻译文本的消息监听器
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.action === "translate") {
		translateWithGoogle(request.text, request.sourceLang || "auto", request.targetLang)
			.then((translation) => {
				sendResponse({ translation: translation || "" });
			})
			.catch((error) => {
				console.error("Error translating text:", error);
				sendResponse({ translation: "" });
			});
		return true; // Indicates that the response is asynchronous
	}

	if (request.action === "lookupDictionary") {
		const sourceLang = (request.sourceLang || "auto").toLowerCase();
		const text = (request.text || "").trim();
		if (!text) {
			sendResponse({ found: false, source: "", entries: [] });
			return false;
		}
		if (!(sourceLang === "id-id" || sourceLang === "id" || sourceLang === "auto")) {
			sendResponse({ found: false, source: "", entries: [] });
			return false;
		}
		lookupKateglo(text)
			.then((result) => sendResponse(result))
			.catch((error) => {
				console.error("Dictionary lookup failed:", error);
				sendResponse({ found: false, source: "kateglo", entries: [] });
			});
		return true; // Indicates that the response is asynchronous
	}
});
