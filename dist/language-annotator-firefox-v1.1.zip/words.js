let showAllWords = false;
let uiLang = "zh-TW";
let sortMode = "recent_desc";

const toggleViewBtn = document.getElementById("toggleViewBtn");
const sortModeSelect = document.getElementById("sortMode");
const wordsList = document.getElementById("wordsList");
const wordStats = document.getElementById("wordStats");
const languageStats = document.getElementById("languageStats");
const autoLangHint = document.getElementById("autoLangHint");
const closeBtn = document.getElementById("closeBtn");

document.addEventListener("DOMContentLoaded", function () {
	WordStorage.getUiLanguage().then((lang) => {
		uiLang = lang || "zh-TW";
		applyUiText();
		refreshLanguageChip();
		updateWordsList();
	}).catch(() => {
		uiLang = "zh-TW";
		applyUiText();
		refreshLanguageChip();
		updateWordsList();
	});

	toggleViewBtn.addEventListener("click", function () {
		showAllWords = !showAllWords;
		toggleViewBtn.textContent = showAllWords ? t("show_unlearned") : t("show_all");
		updateWordsList();
	});

	sortModeSelect.addEventListener("change", function () {
		sortMode = sortModeSelect.value;
		updateWordsList();
	});

	closeBtn.addEventListener("click", function () {
		window.close();
	});
});

function refreshLanguageChip() {
	WordStorage.getSourceLang().then((lang) => {
		languageStats.textContent = `${t("source_lang")}：${lang}`;
		autoLangHint.style.display = lang === "auto" ? "block" : "none";
	}).catch(() => {
		languageStats.textContent = `${t("source_lang")}：auto`;
		autoLangHint.style.display = "block";
	});
}

function t(key) {
	return UiI18n.t(uiLang, key);
}

function applyUiText() {
	document.getElementById("wordsTitle").textContent = t("fullscreen");
	document.getElementById("wordsSubtitle").textContent = t("popup_subtitle");
	document.getElementById("settingsLink").textContent = t("settings");
	closeBtn.textContent = t("close_tab");
	toggleViewBtn.textContent = showAllWords ? t("show_unlearned") : t("show_all");
	autoLangHint.textContent = t("auto_hint");
	sortModeSelect.options[0].textContent = t("sort_recent");
	sortModeSelect.options[1].textContent = t("sort_alpha");
}

function updateWordsList() {
	wordsList.innerHTML = "";
	WordStorage.getWords().then((words) => {
		const allWords = Object.keys(words);
		if (sortMode === "alpha_asc") {
			allWords.sort((a, b) => a.localeCompare(b));
		} else {
			allWords.sort((a, b) => {
				const at = words[a] && words[a].createdAt ? words[a].createdAt : 0;
				const bt = words[b] && words[b].createdAt ? words[b].createdAt : 0;
				if (bt !== at) return bt - at;
				return a.localeCompare(b);
			});
		}

		const unlearnedCount = allWords.filter((w) => !words[w].learned).length;
		wordStats.textContent = `${t("words")}：${allWords.length} | ${t("unlearned")}：${unlearnedCount}`;

		allWords.forEach((word) => {
			if (!showAllWords && words[word].learned) return;
			const wordItem = document.createElement("div");
			wordItem.className = "word-item";

			const wordSpan = document.createElement("span");
			wordSpan.className = `word${words[word].learned ? " learned" : ""}`;
			wordSpan.textContent = `${word}: ${words[word].meaning}`;

			const actionWrap = document.createElement("div");
			actionWrap.className = "word-actions";

			const audioButton = document.createElement("button");
			audioButton.className = "action-audio";
			audioButton.textContent = `🔊 ${t("pronounce")}`;
			audioButton.addEventListener("click", function () {
				const utterance = new SpeechSynthesisUtterance(word);
				WordStorage.getSourceLang().then((sourceLang) => {
					utterance.lang = sourceLang;
					speechSynthesis.speak(utterance);
				});
			});

			const markButton = document.createElement("button");
			markButton.className = words[word].learned ? "action-unlearn" : "action-learn";
			markButton.textContent = words[word].learned ? t("unmark") : t("mark");
			markButton.addEventListener("click", function () {
				toggleLearned(word);
			});

			const deleteButton = document.createElement("button");
			deleteButton.className = "action-delete";
			deleteButton.textContent = t("delete");
			deleteButton.addEventListener("click", function () {
				deleteWord(word);
			});

			actionWrap.appendChild(audioButton);
			actionWrap.appendChild(markButton);
			actionWrap.appendChild(deleteButton);
			wordItem.appendChild(wordSpan);
			wordItem.appendChild(actionWrap);
			wordsList.appendChild(wordItem);
		});

		if (!wordsList.hasChildNodes()) {
			const empty = document.createElement("div");
			empty.className = "empty";
			empty.textContent = t("empty_words");
			wordsList.appendChild(empty);
		}
	});
}

function deleteWord(word) {
	WordStorage.getWords().then((words) => {
		delete words[word];
		return WordStorage.saveWords(words);
	}).then(() => {
		updateWordsList();
		UiToast.show(t("deleted"), "success");
	}).catch(() => {
		UiToast.show(t("save_failed"), "error");
	});
}

function toggleLearned(word) {
	WordStorage.getWords().then((words) => {
		words[word].learned = !words[word].learned;
		return WordStorage.saveWords(words);
	}).then(() => {
		updateWordsList();
		UiToast.show(t("saved"), "success");
	}).catch(() => {
		UiToast.show(t("save_failed"), "error");
	});
}
