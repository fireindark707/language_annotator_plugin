(function (global) {
	const DICT = {
		"zh-TW": {
			popup_title: "單字中心",
			popup_subtitle: "檢視與管理你的學習單字。",
			settings: "設定",
			show_all: "顯示全部",
			show_unlearned: "只看未學會",
			export: "匯出",
			import: "匯入",
			fullscreen: "全屏瀏覽",
			pronounce: "發音",
			delete: "刪除",
			mark: "標記已學會",
			unmark: "取消標記",
			empty_words: "目前沒有可顯示的單字。",
			source_lang: "來源語言",
			words: "單字",
			unlearned: "未學會",
			options_title: "翻譯設定",
			options_desc: "設定即時翻譯使用的來源語言。",
			current_lang: "目前語言",
			translation_source: "翻譯來源語言",
			auto_translate: "勾選後自動翻譯",
			auto_translate_desc: "選取文字時自動顯示翻譯浮框",
			ui_language: "介面語言",
			save: "儲存", close_tab: "關閉分頁",
			auto_hint: "目前來源語言為 Auto，可能影響發音準確度。建議到設定中手動選擇語言。",
			saved: "已儲存",
			save_failed: "儲存失敗",
			deleted: "已刪除",
			imported: "匯入成功",
			import_failed: "匯入失敗",
			exported: "匯出成功",
			sort_recent: "依加入順序（新到舊）",
			sort_alpha: "依字母順序（A-Z）",
			import_export: "匯入 / 匯出字庫"
		},
		"en": {
			popup_title: "Vocabulary Hub", popup_subtitle: "Review and manage your learning words.", settings: "Settings",
			show_all: "Show All", show_unlearned: "Show Unlearned", export: "Export", import: "Import", fullscreen: "Full Screen",
			pronounce: "Pronounce", delete: "Delete", mark: "Mark Learned", unmark: "Unmark",
			empty_words: "No words in this view yet.", source_lang: "Source", words: "Words", unlearned: "Unlearned",
			options_title: "Translation Settings", options_desc: "Set the source language used for instant translation.",
			current_lang: "Current language", translation_source: "Translation Source Language",
			auto_translate: "Auto translate on selection", auto_translate_desc: "Show translation popup when text is selected",
			ui_language: "UI Language", save: "Save", close_tab: "Close Tab",
			auto_hint: "Source language is Auto now, which may affect pronunciation accuracy. Set it manually in Settings.",
			saved: "Saved", save_failed: "Save failed",
			deleted: "Deleted", imported: "Import successful", import_failed: "Import failed", exported: "Exported",
			sort_recent: "By Added Time (Newest First)", sort_alpha: "Alphabetical (A-Z)", import_export: "Import / Export Vocabulary"
		},
		"ja": {
			popup_title: "単語センター", popup_subtitle: "学習単語を確認・管理します。", settings: "設定",
			show_all: "すべて表示", show_unlearned: "未学習のみ", export: "エクスポート", import: "インポート", fullscreen: "全画面表示",
			pronounce: "発音", delete: "削除", mark: "学習済みにする", unmark: "学習済み解除",
			empty_words: "表示できる単語がありません。", source_lang: "元言語", words: "単語", unlearned: "未学習",
			options_title: "翻訳設定", options_desc: "即時翻訳の元言語を設定します。",
			current_lang: "現在の言語", translation_source: "翻訳元言語",
			auto_translate: "選択時に自動翻訳", auto_translate_desc: "テキスト選択時に翻訳ポップアップを表示",
			ui_language: "UI言語", save: "保存", close_tab: "タブを閉じる",
			auto_hint: "現在の翻訳元言語は Auto です。発音の精度に影響する可能性があります。設定で手動選択をおすすめします。",
			saved: "保存しました", save_failed: "保存失敗",
			deleted: "削除しました", imported: "インポート成功", import_failed: "インポート失敗", exported: "エクスポート成功",
			sort_recent: "追加順（新しい順）", sort_alpha: "アルファベット順（A-Z）", import_export: "単語のインポート / エクスポート"
		},
		"ko": {
			popup_title: "단어 센터", popup_subtitle: "학습 단어를 확인하고 관리하세요.", settings: "설정",
			show_all: "전체 보기", show_unlearned: "미학습만", export: "내보내기", import: "가져오기", fullscreen: "전체 화면",
			pronounce: "발음", delete: "삭제", mark: "학습 표시", unmark: "표시 해제",
			empty_words: "표시할 단어가 없습니다.", source_lang: "원문 언어", words: "단어", unlearned: "미학습",
			options_title: "번역 설정", options_desc: "즉시 번역에 사용할 원문 언어를 설정합니다.",
			current_lang: "현재 언어", translation_source: "번역 원문 언어",
			auto_translate: "선택 시 자동 번역", auto_translate_desc: "텍스트 선택 시 번역 팝업 표시",
			ui_language: "UI 언어", save: "저장", close_tab: "탭 닫기",
			auto_hint: "현재 원문 언어가 Auto로 설정되어 있어 발음 정확도에 영향을 줄 수 있습니다. 설정에서 수동 선택을 권장합니다.",
			saved: "저장됨", save_failed: "저장 실패",
			deleted: "삭제됨", imported: "가져오기 성공", import_failed: "가져오기 실패", exported: "내보내기 성공",
			sort_recent: "추가순(최신 먼저)", sort_alpha: "알파벳순(A-Z)", import_export: "단어 가져오기 / 내보내기"
		},
		"id": {
			popup_title: "Pusat Kosakata", popup_subtitle: "Lihat dan kelola kata belajar Anda.", settings: "Pengaturan",
			show_all: "Tampilkan Semua", show_unlearned: "Hanya Belum Dipelajari", export: "Ekspor", import: "Impor", fullscreen: "Layar Penuh",
			pronounce: "Ucapkan", delete: "Hapus", mark: "Tandai Dipelajari", unmark: "Batalkan Tanda",
			empty_words: "Tidak ada kata untuk ditampilkan.", source_lang: "Bahasa Sumber", words: "Kata", unlearned: "Belum Dipelajari",
			options_title: "Pengaturan Terjemahan", options_desc: "Atur bahasa sumber untuk terjemahan instan.",
			current_lang: "Bahasa saat ini", translation_source: "Bahasa Sumber Terjemahan",
			auto_translate: "Terjemah otomatis saat memilih", auto_translate_desc: "Tampilkan popup terjemahan saat teks dipilih",
			ui_language: "Bahasa UI", save: "Simpan", close_tab: "Tutup Tab",
			auto_hint: "Bahasa sumber saat ini Auto, ini dapat memengaruhi akurasi pelafalan. Disarankan pilih manual di Pengaturan.",
			saved: "Tersimpan", save_failed: "Gagal menyimpan",
			deleted: "Dihapus", imported: "Impor berhasil", import_failed: "Impor gagal", exported: "Ekspor berhasil",
			sort_recent: "Urut Waktu Tambah (Terbaru)", sort_alpha: "Urut Abjad (A-Z)", import_export: "Impor / Ekspor Kosakata"
		},
		"ru": {
			popup_title: "Центр слов", popup_subtitle: "Просматривайте и управляйте изучаемыми словами.", settings: "Настройки",
			show_all: "Показать все", show_unlearned: "Только невыученные", export: "Экспорт", import: "Импорт", fullscreen: "Полный экран",
			pronounce: "Произнести", delete: "Удалить", mark: "Отметить выученным", unmark: "Снять отметку",
			empty_words: "Нет слов для отображения.", source_lang: "Исходный язык", words: "Слова", unlearned: "Невыученные",
			options_title: "Настройки перевода", options_desc: "Установите исходный язык для мгновенного перевода.",
			current_lang: "Текущий язык", translation_source: "Исходный язык перевода",
			auto_translate: "Автоперевод при выделении", auto_translate_desc: "Показывать перевод при выделении текста",
			ui_language: "Язык интерфейса", save: "Сохранить", close_tab: "Закрыть вкладку",
			auto_hint: "Сейчас исходный язык установлен как Auto, это может повлиять на точность произношения. Рекомендуется выбрать язык вручную в настройках.",
			saved: "Сохранено", save_failed: "Ошибка сохранения",
			deleted: "Удалено", imported: "Импорт успешно", import_failed: "Ошибка импорта", exported: "Экспорт успешно",
			sort_recent: "По времени добавления (сначала новые)", sort_alpha: "По алфавиту (A-Z)", import_export: "Импорт / Экспорт словаря"
		},
		"es": {
			popup_title: "Centro de Vocabulario", popup_subtitle: "Revisa y gestiona tus palabras de aprendizaje.", settings: "Configuración",
			show_all: "Mostrar todo", show_unlearned: "Solo no aprendidas", export: "Exportar", import: "Importar", fullscreen: "Pantalla completa",
			pronounce: "Pronunciar", delete: "Eliminar", mark: "Marcar aprendida", unmark: "Quitar marca",
			empty_words: "No hay palabras para mostrar.", source_lang: "Idioma origen", words: "Palabras", unlearned: "No aprendidas",
			options_title: "Configuración de traducción", options_desc: "Define el idioma de origen para la traducción instantánea.",
			current_lang: "Idioma actual", translation_source: "Idioma de origen",
			auto_translate: "Traducir automáticamente al seleccionar", auto_translate_desc: "Mostrar traducción al seleccionar texto",
			ui_language: "Idioma de la interfaz", save: "Guardar", close_tab: "Cerrar pestaña",
			auto_hint: "El idioma de origen está en Auto y puede afectar la precisión de pronunciación. Se recomienda elegirlo manualmente en Configuración.",
			saved: "Guardado", save_failed: "Error al guardar",
			deleted: "Eliminado", imported: "Importación exitosa", import_failed: "Error de importación", exported: "Exportado",
			sort_recent: "Por orden de agregado (más nuevo primero)", sort_alpha: "Orden alfabético (A-Z)", import_export: "Importar / Exportar vocabulario"
		}
	};

	global.UiI18n = {
		t(lang, key) {
			const table = DICT[lang] || DICT["zh-TW"];
			return table[key] || key;
		}
	};
})(globalThis);
