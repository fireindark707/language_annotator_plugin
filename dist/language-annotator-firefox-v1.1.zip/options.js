function getSelectedLabel(selectEl) {
	const option = selectEl.options[selectEl.selectedIndex];
	return option ? option.textContent : "-";
}

document.addEventListener("DOMContentLoaded", function () {
	const sourceLangSelect = document.getElementById("sourceLang");
	const uiLanguageSelect = document.getElementById("uiLanguage");
	const autoTranslateCheckbox = document.getElementById("autoTranslateOnSelect");
	const currentLang = document.getElementById("currentLang");
	const saveBtn = document.getElementById("save");
	const saveStatus = document.getElementById("saveStatus");
	const exportBtn = document.getElementById("exportBtn");
	const importBtn = document.getElementById("importBtn");
	const importFile = document.getElementById("importFile");

	function t(uiLang, key) {
		return UiI18n.t(uiLang, key);
	}

	function renderCurrentLabel() {
		currentLang.textContent = getSelectedLabel(sourceLangSelect);
	}

	function applyUiLanguage(uiLang) {
		document.getElementById("optionsTitle").textContent = t(uiLang, "options_title");
		document.getElementById("optionsDesc").textContent = t(uiLang, "options_desc");
		document.getElementById("currentLangLabel").textContent = t(uiLang, "current_lang");
		document.getElementById("sourceLangLabel").textContent = t(uiLang, "translation_source");
		document.getElementById("uiLangLabel").textContent = t(uiLang, "ui_language");
		document.getElementById("autoTranslateLabel").textContent = t(uiLang, "auto_translate");
		document.getElementById("autoTranslateDesc").textContent = t(uiLang, "auto_translate_desc");
		document.getElementById("importExportLabel").textContent = t(uiLang, "import_export");
		saveBtn.textContent = t(uiLang, "save");
		exportBtn.textContent = t(uiLang, "export");
		importBtn.textContent = t(uiLang, "import");
	}

	Promise.all([
		WordStorage.getSourceLang(),
		WordStorage.getAutoTranslateOnSelect(),
		WordStorage.getUiLanguage(),
	]).then(function ([savedLang, autoTranslate, uiLang]) {
		sourceLangSelect.value = savedLang || "auto";
		autoTranslateCheckbox.checked = autoTranslate;
		uiLanguageSelect.value = uiLang || "zh-TW";
		applyUiLanguage(uiLanguageSelect.value);
		renderCurrentLabel();
	}).catch(function (error) {
		console.error("Failed to load options:", error);
		uiLanguageSelect.value = "zh-TW";
		applyUiLanguage("zh-TW");
		renderCurrentLabel();
	});

	sourceLangSelect.addEventListener("change", function () {
		renderCurrentLabel();
		saveStatus.textContent = "";
	});

	uiLanguageSelect.addEventListener("change", function () {
		applyUiLanguage(uiLanguageSelect.value);
		saveStatus.textContent = "";
	});

	saveBtn.addEventListener("click", function () {
		const sourceLang = sourceLangSelect.value;
		const autoTranslateOnSelect = autoTranslateCheckbox.checked;
		const uiLanguage = uiLanguageSelect.value;
		Promise.all([
			WordStorage.saveSourceLang(sourceLang),
			WordStorage.saveAutoTranslateOnSelect(autoTranslateOnSelect),
			WordStorage.saveUiLanguage(uiLanguage),
		]).then(function () {
			renderCurrentLabel();
			saveStatus.textContent = t(uiLanguage, "saved");
			UiToast.show(t(uiLanguage, "saved"), "success");
		}).catch(function (error) {
			console.error("Failed to save settings:", error);
			saveStatus.textContent = t(uiLanguage, "save_failed");
			UiToast.show(t(uiLanguage, "save_failed"), "error");
		});
	});

	exportBtn.addEventListener("click", function () {
		const uiLanguage = uiLanguageSelect.value || "zh-TW";
		WordStorage.exportData().then(function (items) {
			const dataStr =
				"data:text/json;charset=utf-8," +
				encodeURIComponent(JSON.stringify(items));
			const a = document.createElement("a");
			a.setAttribute("href", dataStr);
			a.setAttribute("download", "wordlist.json");
			document.body.appendChild(a);
			a.click();
			a.remove();
			UiToast.show(t(uiLanguage, "exported"), "success");
		}).catch(function () {
			UiToast.show(t(uiLanguage, "save_failed"), "error");
		});
	});

	importBtn.addEventListener("click", function () {
		importFile.click();
	});

	importFile.addEventListener("change", function (event) {
		const file = event.target.files[0];
		const uiLanguage = uiLanguageSelect.value || "zh-TW";
		if (!(file && file.type === "application/json")) {
			UiToast.show(t(uiLanguage, "import_failed"), "error");
			return;
		}
		const reader = new FileReader();
		reader.onload = function (e) {
			try {
				const items = JSON.parse(e.target.result);
				WordStorage.importData(items).then(function () {
					UiToast.show(t(uiLanguage, "imported"), "success");
				}).catch(function () {
					UiToast.show(t(uiLanguage, "import_failed"), "error");
				});
			} catch (error) {
				UiToast.show(t(uiLanguage, "import_failed"), "error");
			}
		};
		reader.readAsText(file);
	});
});
