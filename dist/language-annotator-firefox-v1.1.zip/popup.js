let showAllWords = false;
let uiLang = "zh-TW";
let sortMode = "recent_desc";

const toggleViewBtn = document.getElementById("toggleViewBtn");
const fullscreenBtn = document.getElementById("fullscreenBtn");
const sortModeSelect = document.getElementById("sortMode");
const wordsList = document.getElementById("wordsList");
const wordStats = document.getElementById("wordStats");
const languageStats = document.getElementById("languageStats");
const autoLangHint = document.getElementById("autoLangHint");

document.addEventListener("DOMContentLoaded", function () {
	WordStorage.getUiLanguage().then((lang) => {
		uiLang = lang || "zh-TW";
		applyUiText();
		refreshLanguageChip();
		updateWordsList();
	}).catch(() => {
		uiLang = "zh-TW";
		applyUiText();
		refreshLanguageChip();
		updateWordsList();
	});

	toggleViewBtn.addEventListener("click", function () {
		showAllWords = !showAllWords;
		toggleViewBtn.textContent = showAllWords ? t("show_unlearned") : t("show_all");
		updateWordsList();
	});

	fullscreenBtn.addEventListener("click", function () {
		chrome.tabs.create({ url: chrome.runtime.getURL("words.html") });
	});

	sortModeSelect.addEventListener("change", function () {
		sortMode = sortModeSelect.value;
		updateWordsList();
	});

});

function t(key) {
	return UiI18n.t(uiLang, key);
}

function applyUiText() {
	document.getElementById("popupTitle").textContent = t("popup_title");
	document.getElementById("popupSubtitle").textContent = t("popup_subtitle");
	document.getElementById("settingsLink").textContent = t("settings");
	toggleViewBtn.textContent = showAllWords ? t("show_unlearned") : t("show_all");
	fullscreenBtn.textContent = t("fullscreen");
	autoLangHint.textContent = t("auto_hint");
	sortModeSelect.options[0].textContent = t("sort_recent");
	sortModeSelect.options[1].textContent = t("sort_alpha");
}

function refreshLanguageChip() {
	WordStorage.getSourceLang().then((sourceLang) => {
		languageStats.textContent = `${t("source_lang")}：${sourceLang}`;
		autoLangHint.style.display = sourceLang === "auto" ? "block" : "none";
	}).catch((error) => {
		console.error("Failed to load source language:", error);
		languageStats.textContent = `${t("source_lang")}：auto`;
		autoLangHint.style.display = "block";
	});
}

function updateWordsList() {
	wordsList.innerHTML = "";

	WordStorage.getWords().then((words) => {
		const wordsArray = Object.keys(words);
		if (sortMode === "alpha_asc") {
			wordsArray.sort((a, b) => a.localeCompare(b));
		} else {
			wordsArray.sort((a, b) => {
				const at = words[a] && words[a].createdAt ? words[a].createdAt : 0;
				const bt = words[b] && words[b].createdAt ? words[b].createdAt : 0;
				if (bt !== at) return bt - at;
				return a.localeCompare(b);
			});
		}
		const unlearnedCount = wordsArray.filter((word) => !words[word].learned).length;
		wordStats.textContent = `${t("words")}：${wordsArray.length} | ${t("unlearned")}：${unlearnedCount}`;

		wordsArray.forEach((word) => {
			if (!showAllWords && words[word].learned) {
				return;
			}

			const wordItem = document.createElement("div");
			wordItem.className = "word-item";

			const wordSpan = document.createElement("span");
			wordSpan.className = `word${words[word].learned ? " learned" : ""}`;
			wordSpan.textContent = `${word}: ${words[word].meaning}`;

			const actionWrap = document.createElement("div");
			actionWrap.className = "word-actions";

			const audioButton = document.createElement("button");
			audioButton.textContent = `🔊 ${t("pronounce")}`;
			audioButton.className = "action-audio";
			audioButton.addEventListener("click", function () {
				const utterance = new SpeechSynthesisUtterance(word);
				WordStorage.getSourceLang().then((sourceLang) => {
					utterance.lang = sourceLang;
					const voices = window.speechSynthesis.getVoices();
					for (let i = 0; i < voices.length; i += 1) {
						if (voices[i].lang === utterance.lang) {
							utterance.voice = voices[i];
							break;
						}
					}
					speechSynthesis.speak(utterance);
				});
			});

			const deleteButton = document.createElement("button");
			deleteButton.textContent = t("delete");
			deleteButton.className = "action-delete";
			deleteButton.addEventListener("click", function () {
				deleteWord(word);
			});

			const toggleLearnedButton = document.createElement("button");
			toggleLearnedButton.textContent = words[word].learned ? t("unmark") : t("mark");
			toggleLearnedButton.className = words[word].learned
				? "action-unlearn"
				: "action-learn";
			toggleLearnedButton.addEventListener("click", function () {
				toggleLearned(word);
			});

			actionWrap.appendChild(audioButton);
			actionWrap.appendChild(deleteButton);
			actionWrap.appendChild(toggleLearnedButton);
			wordItem.appendChild(wordSpan);
			wordItem.appendChild(actionWrap);
			wordsList.appendChild(wordItem);
		});

		if (!wordsList.hasChildNodes()) {
			const emptyMessage = document.createElement("p");
			emptyMessage.className = "empty";
			emptyMessage.textContent = t("empty_words");
			wordsList.appendChild(emptyMessage);
		}
	}).catch((error) => {
		console.error("Failed to load words:", error);
		wordStats.textContent = `${t("words")}：-`;
	});
}

function deleteWord(word) {
	WordStorage.getWords().then((words) => {
		delete words[word];
		return WordStorage.saveWords(words);
	}).then(() => {
		updateWordsList();
		UiToast.show(t("deleted"), "success");
	}).catch((error) => {
		console.error("Failed to delete word:", error);
		UiToast.show(t("save_failed"), "error");
	});
}

function toggleLearned(word) {
	WordStorage.getWords().then((words) => {
		words[word].learned = !words[word].learned;
		return WordStorage.saveWords(words);
	}).then(() => {
		updateWordsList();
		UiToast.show(t("saved"), "success");
	}).catch((error) => {
		console.error("Failed to toggle learned state:", error);
		UiToast.show(t("save_failed"), "error");
	});
}
